﻿namespace Sistema_para_Amazon
{
    partial class Anular_Facturas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CajaTex1 = new System.Windows.Forms.TextBox();
            this.CajaTex2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mENUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNULARFACTURASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.javier_Muller_y_George_JaramilloDataSet = new Sistema_para_Amazon.Javier_Muller_y_George_JaramilloDataSet();
            this.javierMulleryGeorgeJaramilloDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.facturaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.facturaTableAdapter = new Sistema_para_Amazon.Javier_Muller_y_George_JaramilloDataSetTableAdapters.facturaTableAdapter();
            this.numerofacturaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombreemisorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rUTDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fechaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codigoproductoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombrecliDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.razonsocialDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.direccioncliDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.comunaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.giroDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valornetoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valordescuentoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iVADataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.valorfinalDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.javier_Muller_y_George_JaramilloDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.javierMulleryGeorgeJaramilloDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.facturaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numerofacturaDataGridViewTextBoxColumn,
            this.nombreemisorDataGridViewTextBoxColumn,
            this.rUTDataGridViewTextBoxColumn,
            this.fechaDataGridViewTextBoxColumn,
            this.codigoproductoDataGridViewTextBoxColumn,
            this.descripcionDataGridViewTextBoxColumn,
            this.nombrecliDataGridViewTextBoxColumn,
            this.razonsocialDataGridViewTextBoxColumn,
            this.direccioncliDataGridViewTextBoxColumn,
            this.comunaDataGridViewTextBoxColumn,
            this.giroDataGridViewTextBoxColumn,
            this.valornetoDataGridViewTextBoxColumn,
            this.valordescuentoDataGridViewTextBoxColumn,
            this.iVADataGridViewTextBoxColumn,
            this.valorfinalDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.facturaBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(25, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(714, 285);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "DE:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(258, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "HASTA:";
            // 
            // CajaTex1
            // 
            this.CajaTex1.Location = new System.Drawing.Point(89, 56);
            this.CajaTex1.Name = "CajaTex1";
            this.CajaTex1.Size = new System.Drawing.Size(100, 22);
            this.CajaTex1.TabIndex = 3;
            // 
            // CajaTex2
            // 
            this.CajaTex2.Location = new System.Drawing.Point(261, 56);
            this.CajaTex2.Name = "CajaTex2";
            this.CajaTex2.Size = new System.Drawing.Size(100, 22);
            this.CajaTex2.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(419, 383);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 55);
            this.button1.TabIndex = 5;
            this.button1.Text = "REFRESACAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(594, 383);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(157, 55);
            this.button2.TabIndex = 6;
            this.button2.Text = "ANULAR FACTURAS";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENUToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 7;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mENUToolStripMenuItem
            // 
            this.mENUToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem,
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem,
            this.aNULARFACTURASToolStripMenuItem,
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem,
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem});
            this.mENUToolStripMenuItem.Name = "mENUToolStripMenuItem";
            this.mENUToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.mENUToolStripMenuItem.Text = "MENU";
            // 
            // iNGRESODEFACTURAINDIVIDUALToolStripMenuItem
            // 
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Name = "iNGRESODEFACTURAINDIVIDUALToolStripMenuItem";
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Text = "1. INGRESO DE FACTURA INDIVIDUAL";
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Click += new System.EventHandler(this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem_Click_1);
            // 
            // iNGRESODEFACTURAMASIVAToolStripMenuItem
            // 
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Name = "iNGRESODEFACTURAMASIVAToolStripMenuItem";
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Text = "2. INGRESO DE FACTURA MASIVA";
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Click += new System.EventHandler(this.iNGRESODEFACTURAMASIVAToolStripMenuItem_Click);
            // 
            // aNULARFACTURASToolStripMenuItem
            // 
            this.aNULARFACTURASToolStripMenuItem.Name = "aNULARFACTURASToolStripMenuItem";
            this.aNULARFACTURASToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.aNULARFACTURASToolStripMenuItem.Text = "3. ANULAR FACTURAS";
            this.aNULARFACTURASToolStripMenuItem.Click += new System.EventHandler(this.aNULARFACTURASToolStripMenuItem_Click);
            // 
            // cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem
            // 
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Name = "cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem";
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Text = "4. CONSULTA DE FACTURAS POR PERIODO DE TIEMPO";
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Click += new System.EventHandler(this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem_Click);
            // 
            // eXPORTACIONAEXCELYPDFToolStripMenuItem
            // 
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Name = "eXPORTACIONAEXCELYPDFToolStripMenuItem";
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Text = "5. EXPORTACION A EXCEL Y PDF";
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Click += new System.EventHandler(this.eXPORTACIONAEXCELYPDFToolStripMenuItem_Click);
            // 
            // javier_Muller_y_George_JaramilloDataSet
            // 
            this.javier_Muller_y_George_JaramilloDataSet.DataSetName = "Javier_Muller_y_George_JaramilloDataSet";
            this.javier_Muller_y_George_JaramilloDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // javierMulleryGeorgeJaramilloDataSetBindingSource
            // 
            this.javierMulleryGeorgeJaramilloDataSetBindingSource.DataSource = this.javier_Muller_y_George_JaramilloDataSet;
            this.javierMulleryGeorgeJaramilloDataSetBindingSource.Position = 0;
            // 
            // facturaBindingSource
            // 
            this.facturaBindingSource.DataMember = "factura";
            this.facturaBindingSource.DataSource = this.javierMulleryGeorgeJaramilloDataSetBindingSource;
            // 
            // facturaTableAdapter
            // 
            this.facturaTableAdapter.ClearBeforeFill = true;
            // 
            // numerofacturaDataGridViewTextBoxColumn
            // 
            this.numerofacturaDataGridViewTextBoxColumn.DataPropertyName = "numero_facturaD";
            this.numerofacturaDataGridViewTextBoxColumn.HeaderText = "numero_factura";
            this.numerofacturaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numerofacturaDataGridViewTextBoxColumn.Name = "numerofacturaDataGridViewTextBoxColumn";
            this.numerofacturaDataGridViewTextBoxColumn.Width = 125;
            // 
            // nombreemisorDataGridViewTextBoxColumn
            // 
            this.nombreemisorDataGridViewTextBoxColumn.DataPropertyName = "nombre_emisorD";
            this.nombreemisorDataGridViewTextBoxColumn.HeaderText = "nombre_emisor";
            this.nombreemisorDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nombreemisorDataGridViewTextBoxColumn.Name = "nombreemisorDataGridViewTextBoxColumn";
            this.nombreemisorDataGridViewTextBoxColumn.Width = 125;
            // 
            // rUTDataGridViewTextBoxColumn
            // 
            this.rUTDataGridViewTextBoxColumn.DataPropertyName = "RUTD";
            this.rUTDataGridViewTextBoxColumn.HeaderText = "RUT";
            this.rUTDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.rUTDataGridViewTextBoxColumn.Name = "rUTDataGridViewTextBoxColumn";
            this.rUTDataGridViewTextBoxColumn.Width = 125;
            // 
            // fechaDataGridViewTextBoxColumn
            // 
            this.fechaDataGridViewTextBoxColumn.DataPropertyName = "fechaD";
            this.fechaDataGridViewTextBoxColumn.HeaderText = "fecha";
            this.fechaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.fechaDataGridViewTextBoxColumn.Name = "fechaDataGridViewTextBoxColumn";
            this.fechaDataGridViewTextBoxColumn.Width = 125;
            // 
            // codigoproductoDataGridViewTextBoxColumn
            // 
            this.codigoproductoDataGridViewTextBoxColumn.DataPropertyName = "codigo_productoD";
            this.codigoproductoDataGridViewTextBoxColumn.HeaderText = "codigo_producto";
            this.codigoproductoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.codigoproductoDataGridViewTextBoxColumn.Name = "codigoproductoDataGridViewTextBoxColumn";
            this.codigoproductoDataGridViewTextBoxColumn.Width = 125;
            // 
            // descripcionDataGridViewTextBoxColumn
            // 
            this.descripcionDataGridViewTextBoxColumn.DataPropertyName = "descripcionD";
            this.descripcionDataGridViewTextBoxColumn.HeaderText = "descripcion";
            this.descripcionDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.descripcionDataGridViewTextBoxColumn.Name = "descripcionDataGridViewTextBoxColumn";
            this.descripcionDataGridViewTextBoxColumn.Width = 125;
            // 
            // nombrecliDataGridViewTextBoxColumn
            // 
            this.nombrecliDataGridViewTextBoxColumn.DataPropertyName = "nombre_cliD";
            this.nombrecliDataGridViewTextBoxColumn.HeaderText = "nombre_cli";
            this.nombrecliDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nombrecliDataGridViewTextBoxColumn.Name = "nombrecliDataGridViewTextBoxColumn";
            this.nombrecliDataGridViewTextBoxColumn.Width = 125;
            // 
            // razonsocialDataGridViewTextBoxColumn
            // 
            this.razonsocialDataGridViewTextBoxColumn.DataPropertyName = "razon_socialD";
            this.razonsocialDataGridViewTextBoxColumn.HeaderText = "razon_social";
            this.razonsocialDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.razonsocialDataGridViewTextBoxColumn.Name = "razonsocialDataGridViewTextBoxColumn";
            this.razonsocialDataGridViewTextBoxColumn.Width = 125;
            // 
            // direccioncliDataGridViewTextBoxColumn
            // 
            this.direccioncliDataGridViewTextBoxColumn.DataPropertyName = "direccion_cliD";
            this.direccioncliDataGridViewTextBoxColumn.HeaderText = "direccion_cli";
            this.direccioncliDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.direccioncliDataGridViewTextBoxColumn.Name = "direccioncliDataGridViewTextBoxColumn";
            this.direccioncliDataGridViewTextBoxColumn.Width = 125;
            // 
            // comunaDataGridViewTextBoxColumn
            // 
            this.comunaDataGridViewTextBoxColumn.DataPropertyName = "comunaD";
            this.comunaDataGridViewTextBoxColumn.HeaderText = "comuna";
            this.comunaDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.comunaDataGridViewTextBoxColumn.Name = "comunaDataGridViewTextBoxColumn";
            this.comunaDataGridViewTextBoxColumn.Width = 125;
            // 
            // giroDataGridViewTextBoxColumn
            // 
            this.giroDataGridViewTextBoxColumn.DataPropertyName = "giroD";
            this.giroDataGridViewTextBoxColumn.HeaderText = "giro";
            this.giroDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.giroDataGridViewTextBoxColumn.Name = "giroDataGridViewTextBoxColumn";
            this.giroDataGridViewTextBoxColumn.Width = 125;
            // 
            // valornetoDataGridViewTextBoxColumn
            // 
            this.valornetoDataGridViewTextBoxColumn.DataPropertyName = "valor_netoD";
            this.valornetoDataGridViewTextBoxColumn.HeaderText = "valor_neto";
            this.valornetoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.valornetoDataGridViewTextBoxColumn.Name = "valornetoDataGridViewTextBoxColumn";
            this.valornetoDataGridViewTextBoxColumn.Width = 125;
            // 
            // valordescuentoDataGridViewTextBoxColumn
            // 
            this.valordescuentoDataGridViewTextBoxColumn.DataPropertyName = "valor_descuentoD";
            this.valordescuentoDataGridViewTextBoxColumn.HeaderText = "valor_descuento";
            this.valordescuentoDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.valordescuentoDataGridViewTextBoxColumn.Name = "valordescuentoDataGridViewTextBoxColumn";
            this.valordescuentoDataGridViewTextBoxColumn.Width = 125;
            // 
            // iVADataGridViewTextBoxColumn
            // 
            this.iVADataGridViewTextBoxColumn.DataPropertyName = "IVAD";
            this.iVADataGridViewTextBoxColumn.HeaderText = "IVA";
            this.iVADataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iVADataGridViewTextBoxColumn.Name = "iVADataGridViewTextBoxColumn";
            this.iVADataGridViewTextBoxColumn.Width = 125;
            // 
            // valorfinalDataGridViewTextBoxColumn
            // 
            this.valorfinalDataGridViewTextBoxColumn.DataPropertyName = "valor_finalD";
            this.valorfinalDataGridViewTextBoxColumn.HeaderText = "valor_final";
            this.valorfinalDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.valorfinalDataGridViewTextBoxColumn.Name = "valorfinalDataGridViewTextBoxColumn";
            this.valorfinalDataGridViewTextBoxColumn.Width = 125;
            // 
            // Anular_Facturas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.CajaTex2);
            this.Controls.Add(this.CajaTex1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Anular_Facturas";
            this.Text = "Anular_Facturas";
            this.Load += new System.EventHandler(this.Anular_Facturas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.javier_Muller_y_George_JaramilloDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.javierMulleryGeorgeJaramilloDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.facturaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox CajaTex1;
        private System.Windows.Forms.TextBox CajaTex2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mENUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNGRESODEFACTURAINDIVIDUALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNGRESODEFACTURAMASIVAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNULARFACTURASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXPORTACIONAEXCELYPDFToolStripMenuItem;
        private System.Windows.Forms.BindingSource javierMulleryGeorgeJaramilloDataSetBindingSource;
        private Javier_Muller_y_George_JaramilloDataSet javier_Muller_y_George_JaramilloDataSet;
        private System.Windows.Forms.BindingSource facturaBindingSource;
        private Javier_Muller_y_George_JaramilloDataSetTableAdapters.facturaTableAdapter facturaTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn numerofacturaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombreemisorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn rUTDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fechaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codigoproductoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombrecliDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn razonsocialDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn direccioncliDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn comunaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn giroDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valornetoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valordescuentoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iVADataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valorfinalDataGridViewTextBoxColumn;
    }
}