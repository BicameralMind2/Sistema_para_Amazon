﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_para_Amazon
{
    class BConsultas
    {
        public int Revision_usuario(string nombre, string contra)
        {
            BDatos obj = new BDatos();
            SqlCommand cmd = new SqlCommand("Revision_Usuario", obj.AbrirCon());
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@nombre", nombre);
            cmd.Parameters.AddWithValue("@contra", contra);
            int dev = Convert.ToInt32(cmd.ExecuteScalar());
            return dev;
        }
        public void estadoBloqueo(string nombre, int estado)
        {
            try
            {
                BDatos obj = new BDatos();
                SqlCommand comand = new SqlCommand("Bloqueo_Usuario", obj.AbrirCon());
                comand.CommandType = CommandType.StoredProcedure;
                comand.Parameters.AddWithValue("@nombre", nombre);
                comand.Parameters.AddWithValue("@estado", estado);
                comand.ExecuteNonQuery();
                obj.CerrarCon();
            }
            catch (Exception)
            {
                MessageBox.Show("ERROR");
            }    
        

        }
        


    }
         
}

