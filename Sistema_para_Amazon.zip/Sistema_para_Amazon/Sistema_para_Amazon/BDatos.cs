﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Security.AccessControl;

namespace Sistema_para_Amazon
{
    class BDatos
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=LAPTOP-L2SD4LPG; Initial Catalog=Javier_Muller_Y_George_Jaramillo; User ID = adminAmazon; Password= asdf; Connect Timeout= 30; Encrypt= False; ApplicationIntent= ReadWrite; MultiSubnetFailover=False");
    public SqlConnection AbrirCon()
        {
            try
            {
                cnn.Open();
                return cnn;
            }
            catch
            {
                return cnn;
            }
        }

    public SqlConnection CerrarCon()
        {
            try
            {
                cnn.Close();
                return cnn;
            }
            catch
            {
                return cnn;
            }
        }
    }
}
