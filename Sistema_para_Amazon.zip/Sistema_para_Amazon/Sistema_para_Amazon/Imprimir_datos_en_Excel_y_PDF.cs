﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_para_Amazon
{
    public partial class Imprimir_datos_en_Excel_y_PDF : Form
    {
        public Imprimir_datos_en_Excel_y_PDF()
        {
            InitializeComponent();
            BDatos ObjBD = new BDatos();
            string Sql = "Select * from factura";
            SqlCommand comando = new SqlCommand(Sql, ObjBD.AbrirCon());
            SqlDataReader leer = comando.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("numero_facturaD", typeof(int)));
            dt.Columns.Add(new DataColumn("nombre_emisorD", typeof(string)));
            dt.Columns.Add(new DataColumn("RUTD", typeof(string)));
            dt.Columns.Add(new DataColumn("fechaD", typeof(DateTime)));
            dt.Columns.Add(new DataColumn("codigo_productoD", typeof(string)));
            dt.Columns.Add(new DataColumn("descripcionD", typeof(string)));
            dt.Columns.Add(new DataColumn("nombre_cliD", typeof(string)));
            dt.Columns.Add(new DataColumn("razon_socialD", typeof(string)));
            dt.Columns.Add(new DataColumn("direccion_cliD", typeof(string)));
            dt.Columns.Add(new DataColumn("comunaD", typeof(string)));
            dt.Columns.Add(new DataColumn("giroD", typeof(string)));
            dt.Columns.Add(new DataColumn("valor_netoD", typeof(int)));
            dt.Columns.Add(new DataColumn("IVAD", typeof(int)));
            dt.Columns.Add(new DataColumn("valor_descuentoD", typeof(int)));
            dt.Columns.Add(new DataColumn("valor_finalD", typeof(int)));
            while (leer.Read())
            {
                string numero_factura = leer["numero_factura"].ToString();
                string nombre_emisor = leer["nombre_emisor"].ToString();
                string RUT = leer["RUT"].ToString();
                string fecha = leer["fecha"].ToString();
                string codigo_producto = leer["codigo_producto"].ToString();
                string descripcion = leer["descripcion"].ToString();
                string nombre_cli = leer["nombre_cli"].ToString();
                string razon_social = leer["razon_social"].ToString();
                string direccion_cli = leer["direccion_cli"].ToString();
                string comuna = leer["comuna"].ToString();
                string giro = leer["giro"].ToString();
                string valor_neto = leer["valor_neto"].ToString();
                string IVA = leer["IVA"].ToString();
                string valor_descuento = leer["valor_descuento"].ToString();
                string valor_final = leer["valor_final"].ToString();
                dt.Rows.Add(numero_factura, nombre_emisor, RUT, fecha, codigo_producto, descripcion, nombre_cli, razon_social, direccion_cli, comuna, giro, valor_neto, IVA, valor_descuento, valor_final);
            }
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.DataSource = dt;
            ObjBD.CerrarCon();
        }

        private void iNGRESODEFACTURAINDIVIDUALToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ingreso_Factura_Individual mv = new Ingreso_Factura_Individual();
            mv.Show();
            this.Hide();
        }

        private void iNGRESODEFACTURAMASIVAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ingreso_Facturas_Masivas mv = new Ingreso_Facturas_Masivas();
            mv.Show();
            this.Hide();
        }

        private void aNULARFACTURASToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Anular_Facturas mv = new Anular_Facturas();
            mv.Show();
            this.Hide();
        }

        private void cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Consulta_global mv = new Consulta_global();
            mv.Show();
            this.Hide();
        }

        private void eXPORTACIONAEXCELYPDFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Imprimir_datos_en_Excel_y_PDF mv = new Imprimir_datos_en_Excel_y_PDF();
            mv.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CajaTex1.Text = "";
            CajaTex2.Text = "";
        }

        private void Imprimir_datos_en_Excel_y_PDF_Load(object sender, EventArgs e)
        {
          
        }
    }
}
