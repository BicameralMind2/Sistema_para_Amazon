﻿namespace Sistema_para_Amazon
{
    partial class Info_Usuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CBDatos1 = new System.Windows.Forms.Label();
            this.CBDatos2 = new System.Windows.Forms.Label();
            this.CBDatos3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.CBDatos4 = new System.Windows.Forms.Label();
            this.CBDatos5 = new System.Windows.Forms.Label();
            this.CBDatos6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.CBDatos7 = new System.Windows.Forms.Label();
            this.CBDatos8 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mENUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNULARFACTURASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.8F);
            this.label1.Location = new System.Drawing.Point(250, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(269, 54);
            this.label1.TabIndex = 0;
            this.label1.Text = "USTED ES:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(215, 166);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "NOMBRES:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(328, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(150, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "APELLIDO PATERNO:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(499, 166);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(152, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "APELLIDO MATERNO:";
            // 
            // CBDatos1
            // 
            this.CBDatos1.AutoSize = true;
            this.CBDatos1.Location = new System.Drawing.Point(218, 203);
            this.CBDatos1.Name = "CBDatos1";
            this.CBDatos1.Size = new System.Drawing.Size(20, 17);
            this.CBDatos1.TabIndex = 4;
            this.CBDatos1.Text = "...";
            // 
            // CBDatos2
            // 
            this.CBDatos2.AutoSize = true;
            this.CBDatos2.Location = new System.Drawing.Point(328, 203);
            this.CBDatos2.Name = "CBDatos2";
            this.CBDatos2.Size = new System.Drawing.Size(20, 17);
            this.CBDatos2.TabIndex = 5;
            this.CBDatos2.Text = "...";
            // 
            // CBDatos3
            // 
            this.CBDatos3.AutoSize = true;
            this.CBDatos3.Location = new System.Drawing.Point(499, 203);
            this.CBDatos3.Name = "CBDatos3";
            this.CBDatos3.Size = new System.Drawing.Size(20, 17);
            this.CBDatos3.TabIndex = 6;
            this.CBDatos3.Text = "...";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(215, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 17);
            this.label5.TabIndex = 7;
            this.label5.Text = "RUT:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(331, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 17);
            this.label6.TabIndex = 8;
            this.label6.Text = "RAZON SOCIAL:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(499, 253);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 17);
            this.label7.TabIndex = 9;
            this.label7.Text = "CARGO:";
            // 
            // CBDatos4
            // 
            this.CBDatos4.AutoSize = true;
            this.CBDatos4.Location = new System.Drawing.Point(218, 292);
            this.CBDatos4.Name = "CBDatos4";
            this.CBDatos4.Size = new System.Drawing.Size(24, 17);
            this.CBDatos4.TabIndex = 10;
            this.CBDatos4.Text = " ...";
            // 
            // CBDatos5
            // 
            this.CBDatos5.AutoSize = true;
            this.CBDatos5.Location = new System.Drawing.Point(328, 292);
            this.CBDatos5.Name = "CBDatos5";
            this.CBDatos5.Size = new System.Drawing.Size(20, 17);
            this.CBDatos5.TabIndex = 11;
            this.CBDatos5.Text = "...";
            // 
            // CBDatos6
            // 
            this.CBDatos6.AutoSize = true;
            this.CBDatos6.Location = new System.Drawing.Point(499, 292);
            this.CBDatos6.Name = "CBDatos6";
            this.CBDatos6.Size = new System.Drawing.Size(20, 17);
            this.CBDatos6.TabIndex = 12;
            this.CBDatos6.Text = "...";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(218, 338);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 17);
            this.label8.TabIndex = 13;
            this.label8.Text = "GENERO:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(331, 338);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 17);
            this.label9.TabIndex = 14;
            this.label9.Text = "DIRECCIÓN:";
            // 
            // CBDatos7
            // 
            this.CBDatos7.AutoSize = true;
            this.CBDatos7.Location = new System.Drawing.Point(221, 388);
            this.CBDatos7.Name = "CBDatos7";
            this.CBDatos7.Size = new System.Drawing.Size(20, 17);
            this.CBDatos7.TabIndex = 16;
            this.CBDatos7.Text = "...";
            // 
            // CBDatos8
            // 
            this.CBDatos8.AutoSize = true;
            this.CBDatos8.Location = new System.Drawing.Point(331, 387);
            this.CBDatos8.Name = "CBDatos8";
            this.CBDatos8.Size = new System.Drawing.Size(20, 17);
            this.CBDatos8.TabIndex = 17;
            this.CBDatos8.Text = "...";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENUToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 19;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mENUToolStripMenuItem
            // 
            this.mENUToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem,
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem,
            this.aNULARFACTURASToolStripMenuItem,
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem,
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem});
            this.mENUToolStripMenuItem.Name = "mENUToolStripMenuItem";
            this.mENUToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.mENUToolStripMenuItem.Text = "MENU";
            // 
            // iNGRESODEFACTURAINDIVIDUALToolStripMenuItem
            // 
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Name = "iNGRESODEFACTURAINDIVIDUALToolStripMenuItem";
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Text = "1. INGRESO DE FACTURA INDIVIDUAL";
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Click += new System.EventHandler(this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem_Click);
            // 
            // iNGRESODEFACTURAMASIVAToolStripMenuItem
            // 
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Name = "iNGRESODEFACTURAMASIVAToolStripMenuItem";
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Text = "2. INGRESO DE FACTURA MASIVA";
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Click += new System.EventHandler(this.iNGRESODEFACTURAMASIVAToolStripMenuItem_Click);
            // 
            // aNULARFACTURASToolStripMenuItem
            // 
            this.aNULARFACTURASToolStripMenuItem.Name = "aNULARFACTURASToolStripMenuItem";
            this.aNULARFACTURASToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.aNULARFACTURASToolStripMenuItem.Text = "3. ANULAR FACTURAS";
            this.aNULARFACTURASToolStripMenuItem.Click += new System.EventHandler(this.aNULARFACTURASToolStripMenuItem_Click);
            // 
            // cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem
            // 
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Name = "cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem";
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Text = "4. CONSULTA DE FACTURAS POR PERIODO DE TIEMPO";
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Click += new System.EventHandler(this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem_Click);
            // 
            // eXPORTACIONAEXCELYPDFToolStripMenuItem
            // 
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Name = "eXPORTACIONAEXCELYPDFToolStripMenuItem";
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Text = "5. EXPORTACION A EXCEL Y PDF";
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Click += new System.EventHandler(this.eXPORTACIONAEXCELYPDFToolStripMenuItem_Click);
            // 
            // Info_Usuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.CBDatos8);
            this.Controls.Add(this.CBDatos7);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CBDatos6);
            this.Controls.Add(this.CBDatos5);
            this.Controls.Add(this.CBDatos4);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.CBDatos3);
            this.Controls.Add(this.CBDatos2);
            this.Controls.Add(this.CBDatos1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Info_Usuario";
            this.Text = "Info_Usuario";
            this.Load += new System.EventHandler(this.Info_Usuario_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label CBDatos1;
        private System.Windows.Forms.Label CBDatos2;
        private System.Windows.Forms.Label CBDatos3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label CBDatos4;
        private System.Windows.Forms.Label CBDatos5;
        private System.Windows.Forms.Label CBDatos6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label CBDatos7;
        private System.Windows.Forms.Label CBDatos8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mENUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNGRESODEFACTURAINDIVIDUALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNGRESODEFACTURAMASIVAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNULARFACTURASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXPORTACIONAEXCELYPDFToolStripMenuItem;
    }
}