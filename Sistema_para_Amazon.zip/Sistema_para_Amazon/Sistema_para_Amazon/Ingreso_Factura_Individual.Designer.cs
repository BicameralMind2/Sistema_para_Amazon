﻿namespace Sistema_para_Amazon
{
    partial class Ingreso_Factura_Individual
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CajaTex1 = new System.Windows.Forms.TextBox();
            this.CajaTex2 = new System.Windows.Forms.TextBox();
            this.CajaTex3 = new System.Windows.Forms.TextBox();
            this.CajaTex4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.CajaTex5 = new System.Windows.Forms.TextBox();
            this.CajaTex6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.CajaTex7 = new System.Windows.Forms.TextBox();
            this.CajaTex8 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.Limpiar_Casillas = new System.Windows.Forms.Button();
            this.Agregar_Factura = new System.Windows.Forms.Button();
            this.CajaTex9 = new System.Windows.Forms.TextBox();
            this.CajaTex10 = new System.Windows.Forms.TextBox();
            this.CajaTex11 = new System.Windows.Forms.TextBox();
            this.CajaTex12 = new System.Windows.Forms.TextBox();
            this.CajaTex13 = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mENUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNULARFACTURASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CajaTex14 = new System.Windows.Forms.TextBox();
            this.CajaTex15 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(190, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "NOMBRE DEL EMISOR:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(353, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "FECHA DE EMISION:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(725, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "DESCRIPCIÓN:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(538, 100);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "CODIGO DEL PRODUCTO:";
            // 
            // CajaTex1
            // 
            this.CajaTex1.Location = new System.Drawing.Point(193, 151);
            this.CajaTex1.Name = "CajaTex1";
            this.CajaTex1.Size = new System.Drawing.Size(157, 22);
            this.CajaTex1.TabIndex = 5;
            // 
            // CajaTex2
            // 
            this.CajaTex2.Location = new System.Drawing.Point(356, 151);
            this.CajaTex2.Name = "CajaTex2";
            this.CajaTex2.Size = new System.Drawing.Size(145, 22);
            this.CajaTex2.TabIndex = 6;
            // 
            // CajaTex3
            // 
            this.CajaTex3.Location = new System.Drawing.Point(525, 150);
            this.CajaTex3.Name = "CajaTex3";
            this.CajaTex3.Size = new System.Drawing.Size(194, 22);
            this.CajaTex3.TabIndex = 7;
            // 
            // CajaTex4
            // 
            this.CajaTex4.Location = new System.Drawing.Point(728, 150);
            this.CajaTex4.Name = "CajaTex4";
            this.CajaTex4.Size = new System.Drawing.Size(262, 22);
            this.CajaTex4.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(193, 202);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "NOMBRE CLIENTE:";
            // 
            // CajaTex5
            // 
            this.CajaTex5.Location = new System.Drawing.Point(193, 251);
            this.CajaTex5.Name = "CajaTex5";
            this.CajaTex5.Size = new System.Drawing.Size(157, 22);
            this.CajaTex5.TabIndex = 10;
            // 
            // CajaTex6
            // 
            this.CajaTex6.Location = new System.Drawing.Point(356, 250);
            this.CajaTex6.Name = "CajaTex6";
            this.CajaTex6.Size = new System.Drawing.Size(145, 22);
            this.CajaTex6.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(353, 202);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "RAZÓN SOCIAL:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(522, 202);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "DIRECCIÓN";
            // 
            // CajaTex7
            // 
            this.CajaTex7.Location = new System.Drawing.Point(525, 250);
            this.CajaTex7.Name = "CajaTex7";
            this.CajaTex7.Size = new System.Drawing.Size(203, 22);
            this.CajaTex7.TabIndex = 14;
            // 
            // CajaTex8
            // 
            this.CajaTex8.Location = new System.Drawing.Point(737, 251);
            this.CajaTex8.Name = "CajaTex8";
            this.CajaTex8.Size = new System.Drawing.Size(242, 22);
            this.CajaTex8.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(749, 202);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 17);
            this.label8.TabIndex = 16;
            this.label8.Text = "COMUNA:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(193, 297);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 17);
            this.label10.TabIndex = 19;
            this.label10.Text = "GIRO:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(353, 297);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 17);
            this.label11.TabIndex = 20;
            this.label11.Text = "RUT CLIENTE:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(520, 297);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(119, 17);
            this.label12.TabIndex = 21;
            this.label12.Text = "N° DE FACTURA:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(782, 297);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 17);
            this.label13.TabIndex = 22;
            this.label13.Text = "DESCUENTO:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(642, 297);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(102, 17);
            this.label14.TabIndex = 23;
            this.label14.Text = "VALOR NETO:";
            // 
            // Limpiar_Casillas
            // 
            this.Limpiar_Casillas.Location = new System.Drawing.Point(581, 394);
            this.Limpiar_Casillas.Name = "Limpiar_Casillas";
            this.Limpiar_Casillas.Size = new System.Drawing.Size(190, 75);
            this.Limpiar_Casillas.TabIndex = 24;
            this.Limpiar_Casillas.Text = "LIMPIAR CASILLAS";
            this.Limpiar_Casillas.UseVisualStyleBackColor = true;
            this.Limpiar_Casillas.Click += new System.EventHandler(this.Limpiar_Casillas_Click);
            // 
            // Agregar_Factura
            // 
            this.Agregar_Factura.Location = new System.Drawing.Point(785, 394);
            this.Agregar_Factura.Name = "Agregar_Factura";
            this.Agregar_Factura.Size = new System.Drawing.Size(194, 75);
            this.Agregar_Factura.TabIndex = 25;
            this.Agregar_Factura.Text = "AGREGAR FACTURA";
            this.Agregar_Factura.UseVisualStyleBackColor = true;
            this.Agregar_Factura.Click += new System.EventHandler(this.button2_Click);
            // 
            // CajaTex9
            // 
            this.CajaTex9.Location = new System.Drawing.Point(193, 336);
            this.CajaTex9.Name = "CajaTex9";
            this.CajaTex9.Size = new System.Drawing.Size(157, 22);
            this.CajaTex9.TabIndex = 27;
            // 
            // CajaTex10
            // 
            this.CajaTex10.Location = new System.Drawing.Point(356, 336);
            this.CajaTex10.Name = "CajaTex10";
            this.CajaTex10.Size = new System.Drawing.Size(142, 22);
            this.CajaTex10.TabIndex = 28;
            this.CajaTex10.Leave += new System.EventHandler(this.CajaTex10_Leave);
            // 
            // CajaTex11
            // 
            this.CajaTex11.Location = new System.Drawing.Point(525, 336);
            this.CajaTex11.Name = "CajaTex11";
            this.CajaTex11.Size = new System.Drawing.Size(114, 22);
            this.CajaTex11.TabIndex = 29;
            // 
            // CajaTex12
            // 
            this.CajaTex12.Location = new System.Drawing.Point(645, 336);
            this.CajaTex12.Name = "CajaTex12";
            this.CajaTex12.Size = new System.Drawing.Size(126, 22);
            this.CajaTex12.TabIndex = 30;
            // 
            // CajaTex13
            // 
            this.CajaTex13.Location = new System.Drawing.Point(785, 336);
            this.CajaTex13.Name = "CajaTex13";
            this.CajaTex13.Size = new System.Drawing.Size(142, 22);
            this.CajaTex13.TabIndex = 31;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENUToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1004, 28);
            this.menuStrip1.TabIndex = 34;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mENUToolStripMenuItem
            // 
            this.mENUToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem,
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem,
            this.aNULARFACTURASToolStripMenuItem,
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem,
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem});
            this.mENUToolStripMenuItem.Name = "mENUToolStripMenuItem";
            this.mENUToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.mENUToolStripMenuItem.Text = "MENU";
            // 
            // iNGRESODEFACTURAINDIVIDUALToolStripMenuItem
            // 
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Name = "iNGRESODEFACTURAINDIVIDUALToolStripMenuItem";
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Text = "1. INGRESO DE FACTURA INDIVIDUAL";
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Click += new System.EventHandler(this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem_Click);
            // 
            // iNGRESODEFACTURAMASIVAToolStripMenuItem
            // 
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Name = "iNGRESODEFACTURAMASIVAToolStripMenuItem";
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Text = "2. INGRESO DE FACTURA MASIVA";
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Click += new System.EventHandler(this.iNGRESODEFACTURAMASIVAToolStripMenuItem_Click);
            // 
            // aNULARFACTURASToolStripMenuItem
            // 
            this.aNULARFACTURASToolStripMenuItem.Name = "aNULARFACTURASToolStripMenuItem";
            this.aNULARFACTURASToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.aNULARFACTURASToolStripMenuItem.Text = "3. ANULAR FACTURAS";
            this.aNULARFACTURASToolStripMenuItem.Click += new System.EventHandler(this.aNULARFACTURASToolStripMenuItem_Click);
            // 
            // cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem
            // 
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Name = "cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem";
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Text = "4. CONSULTA DE FACTURAS POR PERIODO DE TIEMPO";
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Click += new System.EventHandler(this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem_Click);
            // 
            // eXPORTACIONAEXCELYPDFToolStripMenuItem
            // 
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Name = "eXPORTACIONAEXCELYPDFToolStripMenuItem";
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Text = "5. EXPORTACION A EXCEL Y PDF";
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Click += new System.EventHandler(this.eXPORTACIONAEXCELYPDFToolStripMenuItem_Click);
            // 
            // CajaTex14
            // 
            this.CajaTex14.Location = new System.Drawing.Point(933, 336);
            this.CajaTex14.Name = "CajaTex14";
            this.CajaTex14.Size = new System.Drawing.Size(22, 22);
            this.CajaTex14.TabIndex = 35;
            this.CajaTex14.Text = "0";
            // 
            // CajaTex15
            // 
            this.CajaTex15.Location = new System.Drawing.Point(961, 336);
            this.CajaTex15.Name = "CajaTex15";
            this.CajaTex15.Size = new System.Drawing.Size(18, 22);
            this.CajaTex15.TabIndex = 36;
            this.CajaTex15.Text = "0";
            // 
            // Ingreso_Factura_Individual
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 497);
            this.Controls.Add(this.CajaTex15);
            this.Controls.Add(this.CajaTex14);
            this.Controls.Add(this.CajaTex13);
            this.Controls.Add(this.CajaTex12);
            this.Controls.Add(this.CajaTex11);
            this.Controls.Add(this.CajaTex10);
            this.Controls.Add(this.CajaTex9);
            this.Controls.Add(this.Agregar_Factura);
            this.Controls.Add(this.Limpiar_Casillas);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CajaTex8);
            this.Controls.Add(this.CajaTex7);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CajaTex6);
            this.Controls.Add(this.CajaTex5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.CajaTex4);
            this.Controls.Add(this.CajaTex3);
            this.Controls.Add(this.CajaTex2);
            this.Controls.Add(this.CajaTex1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Ingreso_Factura_Individual";
            this.Text = "Ingresar_Factura_Individual";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox CajaTex1;
        private System.Windows.Forms.TextBox CajaTex2;
        private System.Windows.Forms.TextBox CajaTex3;
        private System.Windows.Forms.TextBox CajaTex4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox CajaTex5;
        private System.Windows.Forms.TextBox CajaTex6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox CajaTex7;
        private System.Windows.Forms.TextBox CajaTex8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button Limpiar_Casillas;
        private System.Windows.Forms.Button Agregar_Factura;
        private System.Windows.Forms.TextBox CajaTex9;
        private System.Windows.Forms.TextBox CajaTex10;
        private System.Windows.Forms.TextBox CajaTex11;
        private System.Windows.Forms.TextBox CajaTex12;
        private System.Windows.Forms.TextBox CajaTex13;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mENUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNGRESODEFACTURAINDIVIDUALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNGRESODEFACTURAMASIVAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNULARFACTURASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXPORTACIONAEXCELYPDFToolStripMenuItem;
        private System.Windows.Forms.TextBox CajaTex14;
        private System.Windows.Forms.TextBox CajaTex15;
    }
}