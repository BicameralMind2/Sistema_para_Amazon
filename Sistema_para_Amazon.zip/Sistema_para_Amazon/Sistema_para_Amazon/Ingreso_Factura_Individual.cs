﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_para_Amazon
{
    public partial class Ingreso_Factura_Individual : Form
    {
        SqlConnection cnn = new SqlConnection("Data Source=LAPTOP-L2SD4LPG; Initial Catalog=Javier_Muller_Y_George_Jaramillo; User ID = adminAmazon; Password= asdf; Connect Timeout= 30; Encrypt= False; ApplicationIntent= ReadWrite; MultiSubnetFailover=False");

        public Ingreso_Factura_Individual()
        {
            InitializeComponent();

        }


        private void iNGRESODEFACTURAINDIVIDUALToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ingreso_Factura_Individual mv = new Ingreso_Factura_Individual();
            mv.Show();
            this.Hide();
        }

        private void iNGRESODEFACTURAMASIVAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ingreso_Facturas_Masivas mv = new Ingreso_Facturas_Masivas();
            mv.Show();
            this.Hide();
        }

        private void aNULARFACTURASToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Anular_Facturas mv = new Anular_Facturas();
            mv.Show();
            this.Hide();
        }

        private void cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Consulta_global mv = new Consulta_global();
            mv.Show();
            this.Hide();
        }

        private void eXPORTACIONAEXCELYPDFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Imprimir_datos_en_Excel_y_PDF mv = new Imprimir_datos_en_Excel_y_PDF();
            mv.Show();
            this.Hide();
        }

        public void LimpiarCsilla()
        {
            CajaTex1.Text = "";
            CajaTex2.Text = "";
            CajaTex3.Text = "";
            CajaTex4.Text = "";
            CajaTex5.Text = "";
            CajaTex6.Text = "";
            CajaTex7.Text = "";
            CajaTex8.Text = "";
            CajaTex9.Text = "";
            CajaTex10.Text = "";
            CajaTex11.Text = "";
            CajaTex12.Text = "";
            CajaTex13.Text = "";
        }

        private void Limpiar_Casillas_Click(object sender, EventArgs e)
        {
            //Para dejar todas las cajas de texto en blanco
            LimpiarCsilla();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string mensaje = "";
            DataTable resultado;
            string consultar = "select * from factura where RUT= '" + CajaTex10.Text + "'";
            string consultar2 = "select * from producto where id_producto= '" + CajaTex3.Text + "'";
            Validacion Numerico = new Validacion();
            if (CajaTex1.Text == "" || CajaTex2.Text == "" || CajaTex3.Text == " " || CajaTex4.Text == " " || CajaTex5.Text == " " || CajaTex6.Text == " " || CajaTex7.Text == " " || CajaTex8.Text == " " || CajaTex9.Text == " " || CajaTex10.Text == " " || CajaTex11.Text == " " || CajaTex12.Text == " " || CajaTex13.Text == " ")
            {
                MessageBox.Show("TIENE QUE RELLENAR TODOS LOS CAMPOS POSIBLES");
            }

            else
            {

                if (!Numerico.IsNumeric(CajaTex3.Text))
                {
                    MessageBox.Show("SOLO VALORES NUMERICOS PARA EL CAMPO: NUMERO FACTURA");
                }
                else
                {
                    if (!Numerico.IsNumeric(CajaTex12.Text))
                    {
                        MessageBox.Show("SOLO VALORES NUMERICOS PARA EL CAMPO: VALOR NETO");
                    }
                    if (!Numerico.IsNumeric(CajaTex13.Text))
                    {
                        MessageBox.Show("SOLO VALORES NUMERICOS PARA EL CAMPO: VALOR DESCUENTO");
                    }

                  
                    else
                    {
                        if(CajaTex10.Text == consultar){
                            MessageBox.Show("NO SE HALLA ESE RUT EN EL SISTEMA");
                            }
                        if(CajaTex3.Text == consultar2)
                        {
                            MessageBox.Show("NO SE HALLO EL CODIGO DE PRODUCTO");
                        }
                               else
                                    {

                                
                       
                                        try
                                           {

                                     

                                cnn.Open();
                                    SqlCommand cmd = new SqlCommand("Ingresar_Factura", cnn);
                                    cmd.CommandType = CommandType.StoredProcedure;
                                    cmd.Parameters.AddWithValue("numero_factura", CajaTex11.Text);
                                    cmd.Parameters.AddWithValue("nombre_emisor", CajaTex1.Text);
                                    cmd.Parameters.AddWithValue("RUT", CajaTex10.Text);
                                    cmd.Parameters.AddWithValue("fecha", CajaTex2.Text);
                                    cmd.Parameters.AddWithValue("codigo_producto", Convert.ToInt32(CajaTex3.Text));
                                    cmd.Parameters.AddWithValue("descripcion", CajaTex4.Text);
                                    cmd.Parameters.AddWithValue("nombre_cli", CajaTex5.Text);
                                    cmd.Parameters.AddWithValue("razon_social", CajaTex6.Text);
                                    cmd.Parameters.AddWithValue("direccion_cli", CajaTex7.Text);
                                    cmd.Parameters.AddWithValue("comuna", CajaTex8.Text);
                                    cmd.Parameters.AddWithValue("giro", CajaTex9.Text);
                                    cmd.Parameters.AddWithValue("valor_neto", CajaTex12.Text);
                                    cmd.Parameters.AddWithValue("valor_descuento", CajaTex13.Text);
                                    SqlParameter paramId = new SqlParameter("mensaje", SqlDbType.VarChar, 1000);
                                    paramId.Direction = ParameterDirection.Output;
                                    cmd.Parameters.Add(paramId);
                                    cmd.ExecuteNonQuery();
                                mensaje = Convert.ToString(cmd.Parameters["mensaje"].Value);
                                cnn.Close();

                                    MessageBox.Show(mensaje);
                                  
                                   
                                

                                   
                                           }
                                            catch (Exception ex)
                                           {
                                cnn.Close();
                                MessageBox.Show(ex.ToString());
                                           }
                    }
                }
            }
        }

         }

        private void CajaTex10_Leave(object sender, EventArgs e)
        {
            MessageBox.Show("entro"); //activar foco del texbox
        }
    }
}
