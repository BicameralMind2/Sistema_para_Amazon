﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_para_Amazon
{


    public partial class Ingreso_Usuario : Form
    {
        public static string usuario;
        public Ingreso_Usuario()
        {
            InitializeComponent();
        }
        int intento = 0;
        private void VERIFICAR_Click(object sender, EventArgs e)
        {
            Validacion objvalusuario = new Validacion();

            if (objvalusuario.val_usuario(CTexto1.Text, CTexto2.Text) == false)
            {
                BConsultas objconsulta = new BConsultas();
                if (objconsulta.Revision_usuario(CTexto1.Text, CTexto2.Text) == 1)
                {
                    if (objconsulta.Revision_usuario(CTexto1.Text, CTexto2.Text) == 1)
                    {
                        Info_Usuario mv = new Info_Usuario();
                        usuario = CTexto1.Text;
                        mv.Show();

                        this.Hide();
                    }
                    else
                    {
                        men.Text = "SU CUENTA ESTA BLOQUEADA";
                    }

                }
                else
                {
                    men.Text = "Su usuario y clave son incorrectas!!!";
                    intento++;
                }
                if (intento >= 4)
                {
                    int estado = 0;
                    objconsulta.estadoBloqueo(men.Text, estado);
                    men.Text = "SU CUENTA ESTA BLOQUEADA";
                }
            }
            else
            {
                men.Text = "Debe ingresar credenciales!!!";
            }
            
        }

        private void Ingreso_Usuario_Load(object sender, EventArgs e)
        {

        }
    }
}
