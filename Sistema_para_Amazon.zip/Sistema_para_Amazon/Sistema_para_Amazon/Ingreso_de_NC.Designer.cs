﻿namespace Sistema_para_Amazon
{
    partial class Ingreso_de_NC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.mENUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aNULARFACTURASToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CajaTex1 = new System.Windows.Forms.TextBox();
            this.CajaTex2 = new System.Windows.Forms.TextBox();
            this.CajaTex3 = new System.Windows.Forms.TextBox();
            this.CajaTex4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.CajaTex5 = new System.Windows.Forms.TextBox();
            this.CajaTex6 = new System.Windows.Forms.TextBox();
            this.CajaTex7 = new System.Windows.Forms.TextBox();
            this.CajaTex8 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.CajaTex9 = new System.Windows.Forms.TextBox();
            this.CajaTex10 = new System.Windows.Forms.TextBox();
            this.CajaTex11 = new System.Windows.Forms.TextBox();
            this.CajaTex12 = new System.Windows.Forms.TextBox();
            this.CajaTex13 = new System.Windows.Forms.TextBox();
            this.Limpiar_Casillas = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mENUToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1004, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // mENUToolStripMenuItem
            // 
            this.mENUToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem,
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem,
            this.aNULARFACTURASToolStripMenuItem,
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem,
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem});
            this.mENUToolStripMenuItem.Name = "mENUToolStripMenuItem";
            this.mENUToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.mENUToolStripMenuItem.Text = "MENU";
            // 
            // iNGRESODEFACTURAINDIVIDUALToolStripMenuItem
            // 
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Name = "iNGRESODEFACTURAINDIVIDUALToolStripMenuItem";
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Text = "1. INGRESO DE FACTURA INDIVIDUAL";
            this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem.Click += new System.EventHandler(this.iNGRESODEFACTURAINDIVIDUALToolStripMenuItem_Click);
            // 
            // iNGRESODEFACTURAMASIVAToolStripMenuItem
            // 
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Name = "iNGRESODEFACTURAMASIVAToolStripMenuItem";
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Text = "2. INGRESO DE FACTURA MASIVA";
            this.iNGRESODEFACTURAMASIVAToolStripMenuItem.Click += new System.EventHandler(this.iNGRESODEFACTURAMASIVAToolStripMenuItem_Click);
            // 
            // aNULARFACTURASToolStripMenuItem
            // 
            this.aNULARFACTURASToolStripMenuItem.Name = "aNULARFACTURASToolStripMenuItem";
            this.aNULARFACTURASToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.aNULARFACTURASToolStripMenuItem.Text = "3. ANULAR FACTURAS";
            this.aNULARFACTURASToolStripMenuItem.Click += new System.EventHandler(this.aNULARFACTURASToolStripMenuItem_Click);
            // 
            // cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem
            // 
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Name = "cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem";
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Text = "4. CONSULTA DE FACTURAS POR PERIODO DE TIEMPO";
            this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem.Click += new System.EventHandler(this.cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem_Click);
            // 
            // eXPORTACIONAEXCELYPDFToolStripMenuItem
            // 
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Name = "eXPORTACIONAEXCELYPDFToolStripMenuItem";
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Size = new System.Drawing.Size(453, 26);
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Text = "5. EXPORTACION A EXCEL Y PDF";
            this.eXPORTACIONAEXCELYPDFToolStripMenuItem.Click += new System.EventHandler(this.eXPORTACIONAEXCELYPDFToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(157, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "NOMBRE DEL EMISOR:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(323, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "FECHA DE EMISION:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(478, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(181, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "CODIGO DEL PRODUCTO:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(679, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(104, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "DESCRIPCIÓN:";
            // 
            // CajaTex1
            // 
            this.CajaTex1.Location = new System.Drawing.Point(169, 124);
            this.CajaTex1.Name = "CajaTex1";
            this.CajaTex1.Size = new System.Drawing.Size(151, 22);
            this.CajaTex1.TabIndex = 5;
            // 
            // CajaTex2
            // 
            this.CajaTex2.Location = new System.Drawing.Point(326, 124);
            this.CajaTex2.Name = "CajaTex2";
            this.CajaTex2.Size = new System.Drawing.Size(137, 22);
            this.CajaTex2.TabIndex = 6;
            // 
            // CajaTex3
            // 
            this.CajaTex3.Location = new System.Drawing.Point(481, 123);
            this.CajaTex3.Name = "CajaTex3";
            this.CajaTex3.Size = new System.Drawing.Size(178, 22);
            this.CajaTex3.TabIndex = 7;
            // 
            // CajaTex4
            // 
            this.CajaTex4.Location = new System.Drawing.Point(682, 123);
            this.CajaTex4.Name = "CajaTex4";
            this.CajaTex4.Size = new System.Drawing.Size(293, 22);
            this.CajaTex4.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(166, 192);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "NOMBRE CLIENTE:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(326, 192);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(114, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "RAZÓN SOCIAL:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(478, 192);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 17);
            this.label8.TabIndex = 12;
            this.label8.Text = "DIRECCÍON:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(687, 192);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 17);
            this.label9.TabIndex = 13;
            this.label9.Text = "COMUNA:";
            // 
            // CajaTex5
            // 
            this.CajaTex5.Location = new System.Drawing.Point(169, 236);
            this.CajaTex5.Name = "CajaTex5";
            this.CajaTex5.Size = new System.Drawing.Size(154, 22);
            this.CajaTex5.TabIndex = 14;
            // 
            // CajaTex6
            // 
            this.CajaTex6.Location = new System.Drawing.Point(329, 236);
            this.CajaTex6.Name = "CajaTex6";
            this.CajaTex6.Size = new System.Drawing.Size(134, 22);
            this.CajaTex6.TabIndex = 15;
            // 
            // CajaTex7
            // 
            this.CajaTex7.Location = new System.Drawing.Point(481, 236);
            this.CajaTex7.Name = "CajaTex7";
            this.CajaTex7.Size = new System.Drawing.Size(203, 22);
            this.CajaTex7.TabIndex = 17;
            // 
            // CajaTex8
            // 
            this.CajaTex8.Location = new System.Drawing.Point(690, 236);
            this.CajaTex8.Name = "CajaTex8";
            this.CajaTex8.Size = new System.Drawing.Size(285, 22);
            this.CajaTex8.TabIndex = 18;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(166, 303);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 17);
            this.label10.TabIndex = 19;
            this.label10.Text = "GIRO:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(326, 303);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(102, 17);
            this.label11.TabIndex = 20;
            this.label11.Text = "RUT CLIENTE:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(478, 303);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(74, 17);
            this.label12.TabIndex = 21;
            this.label12.Text = "N° DE NC:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(613, 303);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(102, 17);
            this.label13.TabIndex = 22;
            this.label13.Text = "VALOR NETO:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(766, 303);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 17);
            this.label14.TabIndex = 23;
            this.label14.Text = "DESCUENTO:";
            // 
            // CajaTex9
            // 
            this.CajaTex9.Location = new System.Drawing.Point(169, 340);
            this.CajaTex9.Name = "CajaTex9";
            this.CajaTex9.Size = new System.Drawing.Size(154, 22);
            this.CajaTex9.TabIndex = 24;
            // 
            // CajaTex10
            // 
            this.CajaTex10.Location = new System.Drawing.Point(329, 340);
            this.CajaTex10.Name = "CajaTex10";
            this.CajaTex10.Size = new System.Drawing.Size(134, 22);
            this.CajaTex10.TabIndex = 25;
            // 
            // CajaTex11
            // 
            this.CajaTex11.Location = new System.Drawing.Point(481, 340);
            this.CajaTex11.Name = "CajaTex11";
            this.CajaTex11.Size = new System.Drawing.Size(129, 22);
            this.CajaTex11.TabIndex = 26;
            // 
            // CajaTex12
            // 
            this.CajaTex12.Location = new System.Drawing.Point(616, 340);
            this.CajaTex12.Name = "CajaTex12";
            this.CajaTex12.Size = new System.Drawing.Size(149, 22);
            this.CajaTex12.TabIndex = 27;
            // 
            // CajaTex13
            // 
            this.CajaTex13.Location = new System.Drawing.Point(771, 340);
            this.CajaTex13.Name = "CajaTex13";
            this.CajaTex13.Size = new System.Drawing.Size(204, 22);
            this.CajaTex13.TabIndex = 28;
            // 
            // Limpiar_Casillas
            // 
            this.Limpiar_Casillas.Location = new System.Drawing.Point(591, 399);
            this.Limpiar_Casillas.Name = "Limpiar_Casillas";
            this.Limpiar_Casillas.Size = new System.Drawing.Size(174, 62);
            this.Limpiar_Casillas.TabIndex = 29;
            this.Limpiar_Casillas.Text = "LIMPIAR CASILLAS";
            this.Limpiar_Casillas.UseVisualStyleBackColor = true;
            this.Limpiar_Casillas.Click += new System.EventHandler(this.Limpiar_Casillas_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(771, 399);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(170, 62);
            this.button2.TabIndex = 30;
            this.button2.Text = "AGREGAR NOTA DE CREDITO";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Ingreso_de_NC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 497);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Limpiar_Casillas);
            this.Controls.Add(this.CajaTex13);
            this.Controls.Add(this.CajaTex12);
            this.Controls.Add(this.CajaTex11);
            this.Controls.Add(this.CajaTex10);
            this.Controls.Add(this.CajaTex9);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.CajaTex8);
            this.Controls.Add(this.CajaTex7);
            this.Controls.Add(this.CajaTex6);
            this.Controls.Add(this.CajaTex5);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.CajaTex4);
            this.Controls.Add(this.CajaTex3);
            this.Controls.Add(this.CajaTex2);
            this.Controls.Add(this.CajaTex1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Ingreso_de_NC";
            this.Text = "Ingreso_de_NC";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mENUToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox CajaTex1;
        private System.Windows.Forms.TextBox CajaTex2;
        private System.Windows.Forms.TextBox CajaTex3;
        private System.Windows.Forms.TextBox CajaTex4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox CajaTex5;
        private System.Windows.Forms.TextBox CajaTex6;
        private System.Windows.Forms.TextBox CajaTex7;
        private System.Windows.Forms.TextBox CajaTex8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox CajaTex9;
        private System.Windows.Forms.TextBox CajaTex10;
        private System.Windows.Forms.TextBox CajaTex11;
        private System.Windows.Forms.TextBox CajaTex12;
        private System.Windows.Forms.TextBox CajaTex13;
        private System.Windows.Forms.Button Limpiar_Casillas;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ToolStripMenuItem iNGRESODEFACTURAINDIVIDUALToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem iNGRESODEFACTURAMASIVAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aNULARFACTURASToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXPORTACIONAEXCELYPDFToolStripMenuItem;
    }
}