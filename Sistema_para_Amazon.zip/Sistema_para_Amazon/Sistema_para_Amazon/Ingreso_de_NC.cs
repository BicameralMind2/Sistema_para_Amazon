﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_para_Amazon
{
    public partial class Ingreso_de_NC : Form
    {
        public Ingreso_de_NC()
        {
            InitializeComponent();
        }

        private void iNGRESODEFACTURAINDIVIDUALToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ingreso_Factura_Individual mv = new Ingreso_Factura_Individual();
            mv.Show();
            this.Hide();
        }

        private void iNGRESODEFACTURAMASIVAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ingreso_Facturas_Masivas mv = new Ingreso_Facturas_Masivas();
            mv.Show();
            this.Hide();
        }

        private void aNULARFACTURASToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Anular_Facturas mv = new Anular_Facturas();
            mv.Show();
            this.Hide();
        }

        private void cONSULTADEFACTURASPORPERIODODETIEMPOToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Consulta_global mv = new Consulta_global();
            mv.Show();
            this.Hide();
        }

        private void eXPORTACIONAEXCELYPDFToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Imprimir_datos_en_Excel_y_PDF mv = new Imprimir_datos_en_Excel_y_PDF();
            mv.Show();
            this.Hide();
        }

        private void Limpiar_Casillas_Click(object sender, EventArgs e)
        {
            CajaTex1.Text = " ";
            CajaTex2.Text = " ";
            CajaTex3.Text = " ";
            CajaTex4.Text = " ";
            CajaTex5.Text = " ";
            CajaTex6.Text = " ";
            CajaTex7.Text = " ";
            CajaTex8.Text = " ";
            CajaTex9.Text = " ";
            CajaTex10.Text = " ";
            CajaTex11.Text = " ";
            CajaTex12.Text = " ";
            CajaTex13.Text = " ";
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
