﻿namespace Sistema_para_Amazon
{
    partial class Main
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.ACCEDER = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // ACCEDER
            // 
            this.ACCEDER.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.8F);
            this.ACCEDER.Location = new System.Drawing.Point(182, 247);
            this.ACCEDER.Name = "ACCEDER";
            this.ACCEDER.Size = new System.Drawing.Size(402, 125);
            this.ACCEDER.TabIndex = 0;
            this.ACCEDER.Text = "ACCEDER";
            this.ACCEDER.UseVisualStyleBackColor = true;
            this.ACCEDER.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 17.8F);
            this.label1.Location = new System.Drawing.Point(81, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(615, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "¡BIENVENIDO AL SISTEMA DE REGISTRO!";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ACCEDER);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ACCEDER;
        private System.Windows.Forms.Label label1;
    }
}

