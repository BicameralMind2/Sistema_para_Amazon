﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sistema_para_Amazon
{
    class Validacion
    {
        public bool val_usuario(string usuario, string contra)
        {
            if (usuario == string.Empty || contra == string.Empty)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool IsNumeric(string num)
        {
            try
            {
                double x = Convert.ToDouble(num);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
